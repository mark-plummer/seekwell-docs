'use strict'

module.exports = (condition, trueValue, falseValue) => (condition ? trueValue : falseValue)
